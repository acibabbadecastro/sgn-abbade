# MAXIMOUS v2.0 - Exemplo de Uso

## Configuração do Usuário

```bash
# Edite o arquivo config-template.env
USUARIO="Seu Nome"
EMAIL="seu@email.com"
DATASVR_IP="192.168.1.100"  # Seu servidor
```

## Uso Básico

```bash
# Dashboard
bash scripts/dashboard-status.sh

# Organizar memórias
bash scripts/memory-organizer.sh full
```
