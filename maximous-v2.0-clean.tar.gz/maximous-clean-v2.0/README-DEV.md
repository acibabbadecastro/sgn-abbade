# MAXIMOUS v2.0 - Notas para Desenvolvedores

## Configuração Inicial

Antes de usar, configure:

1. **Editar configurações:**
   ```bash
   bash core/preferences-config.sh
   ```

2. **Configurar servidor de backup:**
   - Edite `scripts/multi-cloud-sync.sh`
   - Defina seu DATASVR/cloud

3. **Configurar SSH keys:**
   ```bash
   ssh-keygen -t ed25519
   # Copie para seus servidores
   ```

## Estrutura de Configuração

```
~/.openclaw/workspace/skills/maximous-v2/
├── .user-preferences.conf    # Suas preferências
├── data/                      # Seus dados
├── secure/                    # Dados criptografados
└── backups/                   # Backups locais
```

## Segurança

- NUNCA commite arquivos em `secure/`
- NUNCA commite `.user-preferences.conf`
- Use `.gitignore` fornecido

---
**Template pronto para personalização!**
