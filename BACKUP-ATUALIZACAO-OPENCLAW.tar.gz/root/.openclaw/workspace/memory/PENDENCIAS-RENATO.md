# 💰 PENDÊNCIAS - RENATO
## Controle de Dívidas e Itens

**Data registro:** 26/04/2026  
**Atualizado por:** Acib ABBADE  
**Arquivo:** Pendências financeiras e materiais

---

## 📋 RESUMO

### RENATO DEVE PARA ACIB:

| # | Item | Valor/Descrição | Status | Data Obs |
|---|------|---------------|--------|----------|
| 1 | **Dinheiro** | R$ 57,00 (praia) | ⏳ Pendente | [adicionar data] |
| 2 | **SSD** | 1 unidade - 240 GB | ⏳ Pendente | [adicionar data] |
| 3 | **Carregador** | 1 unidade - Universal de notebook | ⏳ Pendente | [adicionar data] |

**Total estimado:** R$ 57,00 + SSD 240GB (~R$ 100-150) + Carregador (~R$ 80-120)  
**Valor total aproximado:** R$ 250-350

---

### ACIB DEVE PARA RENATO:

| # | Item | Descrição | Status | Observação |
|---|------|-----------|--------|------------|
| 1 | **Fonte ATX** | 1 unidade - Retirada de gabinete novo que Renato emprestou | ⏳ Pendente | Gabinete emprestado para retirada da fonte |

**Observação:** A fonte foi retirada de um gabinete NOVO que Renato emprestou para esse fim.

---

## 🔄 SITUAÇÃO ATUAL

### Saldo parcial (estimado):

| Quem | Deve | Valor Estimado |
|------|------|----------------|
| **Renato → Acib** | Dinheiro + SSD + Carregador | ~R$ 250-350 |
| **Acib → Renato** | Fonte ATX | ~R$ 80-150 |

**Saldo líquido:** Renato deve para Acib (~R$ 100-200 + itens)

---

## 📝 DETALHES ADICIONAIS

### Contexto:
- **Fonte ATX:** Acib precisava de uma fonte, Renato emprestou um gabinete NOVO para que Acib retirasse a fonte dele
- **SSD 240GB:** Renato ficou de devolver um SSD de 240GB
- **Carregador universal:** Renato ficou de devolver um carregador universal de notebook
- **R$ 57,00:** Dívida de "praia" (passeio, compra, serviço - confirmar contexto)

### Histórico:
- Gabinete novo emprestado: [adicionar data aproximada]
- Fonte já retirada por Acib: ✅ Sim
- Itens pendentes de Renato: SSD + Carregador + Dinheiro

---

## ✅ CHECKLIST DE RESOLUÇÃO

### Para Acib fazer:
- [ ] Verificar se fonte ATX já foi entregue a Renato (ou se ainda está em uso)
- [ ] Confirmar modelo/exact specs da fonte (para documentação)
- [ ] Acertar contas com Renato

### Para Renato fazer:
- [ ] Entregar SSD 240GB para Acib
- [ ] Entregar carregador universal de notebook
- [ ] Pagar/acertar R$ 57,00

### Acerto final sugerido:
- Acib devolve fonte ATX (ou deixa como parte do acerto)
- Renato entrega SSD + Carregador + parte do dinheiro
- Acerto de valores conforme negociação entre vocês

---

## 💡 SUGESTÕES

**Opção 1 - Acerto simples:**
- Acib: "Fica com a fonte"
- Renato: Entrega SSD + Carregador + R$ 57
- **Resultado:** Renato quita dívida

**Opção 2 - Troca:**
- Acib devolve fonte
- Renato devolve SSD + Carregador
- Acerto do dinheiro R$ 57 separado

**Opção 3 - Acerto com dinheiro:**
- Acib fica com fonte (valor ~R$ 100)
- Renato devolve SSD (~R$ 130) + Carregador (~R$ 100) = ~R$ 230
- Renato paga R$ 57
- **Saldo:** Renato deve ~R$ 130 (ajustar conforme valores reais)

---

## 📞 CONTATO RENATO

| Campo | Informação |
|-------|------------|
| Nome | Renato |
| Telefone | [adicionar] |
| Email | [adicionar] |
| Relação | [amigo/colega/parceiro/cliente] |
| Observações | Emprestou gabinete novo para retirada de fonte |

---

## 🔔 LEMBRETES

- **Verificar:** Se fonte já foi usada/entregue
- **Agendar:** Acerto de contas com Renato
- **Documentar:** Data do acerto final quando resolver

---

## 🗂️ ARQUIVOS RELACIONADOS

- Tarefas gerais: TAREFAS-MASTER-26-04-2026.md
- Contatos: contatos-importantes.md

---

*Registrado em: 26/04/2026 12:43*  
*Por: Acib ABBADE (via Stark)*  
*Assistente: Stark*
